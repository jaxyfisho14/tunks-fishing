TUNKS FISHING APP

FILES
- index.html: the game
- manifest.json: app-like install settings
- sw.js: basic offline caching

FREE PUBLISHING WITH GITHUB PAGES
1. On a computer, sign in to GitHub (ask a parent/guardian to help if needed).
2. Create a NEW PUBLIC repository named tunks-fishing.
3. Upload index.html, manifest.json and sw.js to the repository's main/root folder.
4. Open repository Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish. Open the Pages URL it gives you.
8. On iPhone, open that URL in Safari, tap Share, then Add to Home Screen.
   On Android Chrome, use the menu and choose Install app or Add to Home screen.

IMPORTANT
- This is a free installable-style web app, not an App Store/Google Play app.
- The current leaderboard is stored on one device only. It is not shared online yet.
- To make a real shared multiplayer leaderboard, add a database/login service later.
- The weather and tide are simulated game conditions, not live conditions.
- The game saves progress in the browser on that device.
